function Titulo(){
    return(
        <h1 id="titulo">Pense Bem</h1>
    )
}

export default Titulo












