function Saida(){
    return(
        <>
            <p><input type="text" id="visor1" value="*" readonly /></p>
            <p><input type="text" id="visor2" readonly /></p>

        </>
    )
}

export default Saida
















