class Globais {
    static programa = 0
    static num = 1
    static tentativa = 1
    static pontos = 0
    static gabarito = new Array(29)

    static gabarito051 = new Array('D','C','B','D','A','A','D','C','B','B','C','D','D','B','A','B','D','A','B','A','B','D','A','C','A','C','C','B','D','A')
    static gabarito052 = new Array('B','A','B','D','A','C','A','C','C','B','D','D','D','B','D','C','D','D','D','A','C','A','A','B','C','A','A','B','A','D')
    static gabarito053 = new Array('B','B','B','C','D','C','C','D','A','C','A','A','B','C','B','A','D','B','B','D','D','C','C','B','A','D','B','A','D','D')
    static gabarito054 = new Array('B','B','D','C','C','C','B','A','D','B','A','D','B','B','B','B','D','A','B','D','A','B','C','C','D','D','C','C','D','B')
    static gabarito055 = new Array('D','A','A','C','D','B','A','C','D','B','B','D','A','B','D','B','B','D','A','B','D','D','D','C','D','C','B','B','B','A')
}

export default Globais




















